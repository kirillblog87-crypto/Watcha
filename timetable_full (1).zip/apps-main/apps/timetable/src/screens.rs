//! The timetable's screens, in the watch's stock LVGL look: the list, the lesson editor (name row, two pairs of
//! rollers), the keyboard and the "now" countdown. Leaving a screen deletes its page with everything on it.
//!
//! Layout notes for the 466x466 round panel: the visible half-width at row `y` is `isqrt(233² - (y-233)²)`;
//! the keyboard's rows and the bottom buttons are placed so their corners stay inside it (see the tests).

use crate::keys::{self, KEYS, ROW_LEN};
use crate::model::{self, Edit, Schedule, DAY_NAMES, MAX_LESSONS};
use cmf_wp2_app::lv::*;
use cmf_wp2_app::stock::{self, CIRCLE, GREY, ROW_BG, ROW_H, ROW_PRESSED, ROW_W, WHITE};

/// Font slots besides the system font (slot `stock::FONT`).
pub const F48: u8 = 1;
pub const F18: u8 = 2;
pub const F24: u8 = 3;

// bytes one widget group can take: flush first when fewer are left
const GROUP: usize = 620;
/// A lesson row's text starts clear of the curved left edge; the name sits above the time, so they cannot overlap.
const TEXT_X: i16 = 28;
const TEXT_W: i32 = ROW_W - TEXT_X as i32 - 28;
const PILL_PRESSED: i32 = 0xC618;

pub type Flush<'a> = &'a mut dyn FnMut(&mut Batch) -> Result<(), LvError>;

fn room(b: &mut Batch, flush: Flush) -> Result<(), LvError> {
    if b.bytes().len() + GROUP > BUF { flush(b) } else { Ok(()) }
}

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum Kind {
    List,
    Detail,
    Editor,
    Keyboard,
    Now,
}

/// The handles the app reacts to on the current screen; unused ones are `ROOT` (never an event target).
#[derive(Clone, Copy)]
pub struct Screen {
    pub kind: Kind,
    pub page: Obj,
    /// The round "Now" button over the list, a child of the root rather than of the page.
    pub fab: Obj,
    /// List: the day row (tap: next day). Detail: the "Изменить" pill.
    pub day_row: Obj,
    pub edit: Obj,
    pub rows: [Obj; MAX_LESSONS],
    pub add: Obj,
    /// Editor: the title (tap: back), the name row, the four rollers (start h, start m, end h, end m).
    pub back: Obj,
    pub name_row: Obj,
    pub rollers: [Obj; 4],
    pub done: Obj,
    pub delete: Obj,
    /// Keyboard: the keys and their labels, the typed text, the mode key and its label, space, backspace.
    pub keys: [Obj; KEYS],
    pub key_labels: [Obj; KEYS],
    pub shown: Obj,
    pub mode: Obj,
    pub mode_label: Obj,
    pub space: Obj,
    pub bksp: Obj,
    /// Now: the five texts and the bar.
    pub head: Obj,
    pub sub: Obj,
    pub time: Obj,
    pub bar: Obj,
    pub line: Obj,
    pub clock: Obj,
}

const EMPTY: Screen = Screen {
    kind: Kind::List,
    page: ROOT,
    fab: ROOT,
    day_row: ROOT,
    edit: ROOT,
    rows: [ROOT; MAX_LESSONS],
    add: ROOT,
    back: ROOT,
    name_row: ROOT,
    rollers: [ROOT; 4],
    done: ROOT,
    delete: ROOT,
    keys: [ROOT; KEYS],
    key_labels: [ROOT; KEYS],
    shown: ROOT,
    mode: ROOT,
    mode_label: ROOT,
    space: ROOT,
    bksp: ROOT,
    head: ROOT,
    sub: ROOT,
    time: ROOT,
    bar: ROOT,
    line: ROOT,
    clock: ROOT,
};

/// Deletes the current screen: its page (with every object and its scroll bar) and the round button.
pub fn leave(b: &mut Batch, s: &Screen) -> Result<(), LvError> {
    if s.fab != ROOT {
        b.del(s.fab)?;
    }
    if s.page != ROOT { b.del(s.page) } else { Ok(()) }
}

/// A full-screen page that does not scroll (the keyboard and the countdown).
fn plain_page(b: &mut Batch) -> Result<Obj, LvError> {
    let page = b.create(Class::Obj, ROOT)?;
    b.size(page, stock::SCREEN, stock::SCREEN)?;
    for p in [Prop::PadTop, Prop::PadBottom, Prop::PadLeft, Prop::PadRight, Prop::BorderWidth, Prop::BgOpa] {
        b.style(page, p, 0, 0)?;
    }
    b.flags(page, &[], &[Flag::Scrollable])?;
    Ok(page)
}

fn small_label(b: &mut Batch, parent: Obj, font: u8, grey: bool, w: i32, text: &str, y: i16) -> Result<Obj, LvError> {
    let l = b.create(Class::Label, parent)?;
    b.size(l, w, if font == F48 { 60 } else if font == F24 { 32 } else { 24 })?;
    b.align(l, Align::TopMid, 0, y)?;
    b.long_mode(l, LongMode::Dot)?;
    b.style(l, Prop::TextAlign, 0, 2)?;
    b.style(l, Prop::TextFont, 0, font as i32)?;
    if grey {
        b.style(l, Prop::TextColor, 0, GREY)?;
    }
    b.text(l, text)?;
    Ok(l)
}

/// A pill button: the light one (white, black text, the "Готово" of the video) or the dark one.
fn pill(b: &mut Batch, parent: Obj, text: &str, light: bool, w: i32, h: i32) -> Result<(Obj, Obj), LvError> {
    let btn = b.create(Class::Btn, parent)?;
    b.size(btn, w, h)?;
    b.style(btn, Prop::Radius, 0, h / 2)?;
    b.style(btn, Prop::BgColor, 0, if light { WHITE } else { ROW_BG })?;
    b.style(btn, Prop::BgOpa, 0, 255)?;
    b.style(btn, Prop::BgColor, stock::PRESSED, if light { PILL_PRESSED } else { ROW_PRESSED })?;
    b.style(btn, Prop::BgOpa, stock::PRESSED, 255)?;
    let l = b.create(Class::Label, btn)?;
    if light {
        b.style(l, Prop::TextColor, 0, stock::BLACK)?;
    }
    b.text(l, text)?;
    b.align(l, Align::Center, 0, 0)?;
    b.events(btn, &[Ev::Clicked])?;
    Ok((btn, l))
}

/// A stock-looking row with two lines: the name above, a grey line under it.
fn two_lines(b: &mut Batch, row: Obj, name: &str, detail: &str) -> Result<(), LvError> {
    let t = b.create(Class::Label, row)?;
    b.size(t, TEXT_W, 40)?;
    b.long_mode(t, LongMode::Dot)?;
    b.style(t, Prop::TextAlign, 0, 1)?; // left
    b.text(t, name)?;
    b.align(t, Align::LeftMid, TEXT_X, -16)?;
    b.flags(t, &[], &[Flag::Clickable, Flag::Scrollable])?;
    let d = b.create(Class::Label, row)?;
    b.size(d, TEXT_W, 30)?;
    b.long_mode(d, LongMode::Dot)?;
    b.style(d, Prop::TextAlign, 0, 1)?;
    b.style(d, Prop::TextFont, 0, F24 as i32)?;
    b.style(d, Prop::TextColor, 0, GREY)?;
    b.text(d, detail)?;
    b.align(d, Align::LeftMid, TEXT_X, 20)?;
    b.flags(d, &[], &[Flag::Clickable, Flag::Scrollable])
}

fn tappable_row(b: &mut Batch, page: Obj) -> Result<Obj, LvError> {
    let row = stock::card(b, page, ROW_H)?;
    b.style(row, Prop::BgColor, stock::PRESSED, ROW_PRESSED)?;
    b.flags(row, &[Flag::Clickable], &[Flag::Scrollable])?;
    b.events(row, &[Ev::Clicked])?;
    Ok(row)
}

/// The list of one day: title, the day row (tap: the next day), a two-line row per lesson (name, time), "add", the
/// round "Now" button. `today` marks the day row.
pub fn list(b: &mut Batch, flush: Flush, sch: &Schedule, day: usize, today: Option<usize>) -> Result<Screen, LvError> {
    room(b, flush)?;
    let (page, _bar) = stock::page(b)?;
    let mut s = Screen { kind: Kind::List, page, ..EMPTY };
    stock::title(b, page, "Расписание")?;
    room(b, flush)?;
    let row = tappable_row(b, page)?;
    let note = if today == Some(day) { "Сегодня · след. день ›" } else { "След. день ›" };
    two_lines(b, row, DAY_NAMES[day.min(DAY_NAMES.len() - 1)], note)?;
    s.day_row = row;
    for i in 0..sch.len() {
        room(b, flush)?;
        let l = sch.get(i);
        let (mut name, mut t) = ([0u8; 40], [0u8; 11]);
        let row = tappable_row(b, page)?;
        two_lines(b, row, model::display_name(l, i, &mut name), model::range(l.start, l.end, &mut t))?;
        s.rows[i] = row;
    }
    if sch.len() < MAX_LESSONS {
        room(b, flush)?;
        s.add = stock::row(b, page, "+", "Добавить урок", "")?;
    }
    room(b, flush)?;
    let (fab, _l) = pill(b, ROOT, "Сейчас", true, 96, 96)?;
    b.align(fab, Align::BottomMid, 0, -18)?;
    b.style(fab, Prop::Radius, 0, CIRCLE)?;
    s.fab = fab;
    Ok(s)
}

/// A lesson: its name, the day and the time, and the countdown to its end or its start. "Изменить" opens the editor.
pub fn detail(b: &mut Batch, flush: Flush) -> Result<Screen, LvError> {
    room(b, flush)?;
    let page = plain_page(b)?;
    let mut s = Screen { kind: Kind::Detail, page, ..EMPTY };
    s.line = small_label(b, page, F24, false, 260, "", 64)?;
    s.clock = small_label(b, page, F18, true, 260, "", 100)?;
    s.sub = small_label(b, page, F18, true, 300, "", 134)?;
    s.time = small_label(b, page, F48, false, 300, "--:--", 160)?;
    room(b, flush)?;
    let bar = b.create(Class::Bar, page)?;
    b.size(bar, 260, 10)?;
    b.align(bar, Align::TopMid, 0, 234)?;
    b.value(bar, 0, false)?;
    for (part, colour) in [(0, stock::LETTER_BG), (stock::INDICATOR, WHITE)] {
        b.style(bar, Prop::BgColor, part, colour)?;
        b.style(bar, Prop::BgOpa, part, 255)?;
        b.style(bar, Prop::Radius, part, CIRCLE)?;
    }
    s.bar = bar;
    room(b, flush)?;
    let (back, bl) = pill(b, page, "Назад", false, 140, 52)?;
    b.style(bl, Prop::TextFont, 0, F18 as i32)?;
    b.align(back, Align::BottomMid, -74, -70)?;
    s.back = back;
    room(b, flush)?;
    let (edit, el) = pill(b, page, "Изменить", true, 140, 52)?;
    b.style(el, Prop::TextFont, 0, F18 as i32)?;
    b.align(edit, Align::BottomMid, 74, -70)?;
    s.edit = edit;
    Ok(s)
}

/// What changes every second on the lesson screen.
pub fn detail_draw(b: &mut Batch, s: &Screen, name: &str, when: &str, caption: &str, time: &str, bar: i32)
    -> Result<(), LvError> {
    b.text(s.line, name)?;
    b.text(s.clock, when)?;
    b.text(s.sub, caption)?;
    b.text(s.time, time)?;
    b.value(s.bar, bar.clamp(0, 100), false)
}

const HOURS: &str = "00\n01\n02\n03\n04\n05\n06\n07\n08\n09\n10\n11\n12\n13\n14\n15\n16\n17\n18\n19\n20\n21\n22\n23";
const MINUTES: &str = "00\n05\n10\n15\n20\n25\n30\n35\n40\n45\n50\n55";

/// The lesson editor: title (tap: back without saving), the name row, start and end rollers, "Готово", "Удалить".
pub fn editor(b: &mut Batch, flush: Flush, ed: &Edit, existing: bool) -> Result<Screen, LvError> {
    room(b, flush)?;
    let (page, _bar) = stock::page(b)?;
    let mut s = Screen { kind: Kind::Editor, page, ..EMPTY };
    let mut heading = [0u8; 16];
    let mut n = [0u8; 3];
    let mut p = 0;
    for part in ["Урок ", model::number(ed.idx + 1, &mut n)] {
        heading[p..p + part.len()].copy_from_slice(part.as_bytes());
        p += part.len();
    }
    let title = stock::title(b, page, core::str::from_utf8(&heading[..p]).unwrap_or("Урок"))?;
    b.flags(title, &[Flag::Clickable], &[])?;
    b.events(title, &[Ev::Clicked])?;
    s.back = title;

    room(b, flush)?;
    let shown = if ed.name.as_str().is_empty() { "не задано" } else { ed.name.as_str() };
    s.name_row = stock::row(b, page, "А", "Название", shown)?;

    let values = [(ed.sh, ed.sm), (ed.eh, ed.em)];
    for (k, caption) in ["НАЧАЛО УРОКА", "КОНЕЦ УРОКА"].into_iter().enumerate() {
        room(b, flush)?;
        let card = stock::card(b, page, 230)?;
        let c = b.create(Class::Label, card)?;
        b.style(c, Prop::TextColor, 0, GREY)?;
        b.style(c, Prop::TextFont, 0, F18 as i32)?;
        b.text(c, caption)?;
        b.align(c, Align::TopMid, 0, 14)?;
        for j in 0..2 {
            room(b, flush)?;
            let r = b.create(Class::Roller, card)?;
            // not infinite: an infinite roller draws at 4-6 fps (ui-gallery, "Picker")
            b.options(r, if j == 0 { HOURS } else { MINUTES }, false)?;
            b.size(r, 120, 180)?;
            b.align(r, Align::Center, if j == 0 { -70 } else { 70 }, 16)?;
            let v = if j == 0 { values[k].0 } else { values[k].1 };
            b.value(r, v as i32, false)?;
            b.style(r, Prop::BgOpa, 0, 0)?;
            b.style(r, Prop::BorderWidth, 0, 0)?;
            b.style(r, Prop::TextColor, 0, GREY)?;
            b.style(r, Prop::TextLineSpace, 0, 28)?;
            b.style(r, Prop::TextAlign, 0, 2)?;
            b.style(r, Prop::BgOpa, stock::SELECTED, 0)?;
            b.style(r, Prop::TextColor, stock::SELECTED, WHITE)?;
            b.style(r, Prop::TextFont, stock::SELECTED, F48 as i32)?;
            b.events(r, &[Ev::ValueChanged])?;
            s.rollers[k * 2 + j] = r;
        }
        let colon = b.create(Class::Label, card)?;
        b.style(colon, Prop::TextFont, 0, F48 as i32)?;
        b.text(colon, ":")?;
        b.align(colon, Align::Center, 0, 12)?;
    }
    // a roller takes the crown when it is created: back to the page
    b.knob(page)?;
    room(b, flush)?;
    s.done = pill(b, page, "Готово", true, 300, 88)?.0;
    if existing {
        room(b, flush)?;
        s.delete = pill(b, page, "Удалить", false, 300, 88)?.0;
    }
    Ok(s)
}

// Keyboard geometry: key 38x54, gap 3; rows 58 px apart from y 104; the bottom buttons at y 336.
const KEY_W: i32 = 38;
const KEY_H: i32 = 54;
const KEY_GAP: i32 = 3;
const ROW_Y0: i32 = 104;
const ROW_PITCH: i32 = 58;
const BOTTOM_Y: i32 = ROW_Y0 + 4 * ROW_PITCH;
const BOTTOM_H: i32 = 54;
/// Bottom buttons, left to right: backspace, mode, space, done.
const BOTTOM_W: [i32; 4] = [66, 66, 84, 84];

/// The keyboard: the typed text on top, four rows of letters, then backspace, "123"/"АБВ", space and "Готово".
pub fn keyboard(b: &mut Batch, flush: Flush, text: &str, digits: bool) -> Result<Screen, LvError> {
    room(b, flush)?;
    let page = plain_page(b)?;
    let mut s = Screen { kind: Kind::Keyboard, page, ..EMPTY };
    s.shown = small_label(b, page, F24, false, 280, if text.is_empty() { "Название" } else { text }, 54)?;
    let mut key = 0;
    for (r, len) in ROW_LEN.into_iter().enumerate() {
        let width = len as i32 * KEY_W + (len as i32 - 1) * KEY_GAP;
        let x0 = (stock::SCREEN as i32 - width) / 2;
        for c in 0..len {
            room(b, flush)?;
            let btn = b.create(Class::Btn, page)?;
            b.size(btn, KEY_W, KEY_H)?;
            b.align(btn, Align::TopLeft, (x0 + c as i32 * (KEY_W + KEY_GAP)) as i16, (ROW_Y0 + r as i32 * ROW_PITCH) as i16)?;
            b.style(btn, Prop::Radius, 0, 12)?;
            b.style(btn, Prop::BgColor, 0, ROW_BG)?;
            b.style(btn, Prop::BgOpa, 0, 255)?;
            b.style(btn, Prop::BgColor, stock::PRESSED, ROW_PRESSED)?;
            b.style(btn, Prop::BgOpa, stock::PRESSED, 255)?;
            let l = b.create(Class::Label, btn)?;
            b.text(l, keys::label(digits, key))?;
            b.align(l, Align::Center, 0, 0)?;
            b.events(btn, &[Ev::Clicked])?;
            s.keys[key] = btn;
            s.key_labels[key] = l;
            key += 1;
        }
    }
    let total: i32 = BOTTOM_W.iter().sum::<i32>() + 3 * KEY_GAP;
    let mut x = (stock::SCREEN as i32 - total) / 2;
    for (i, w) in BOTTOM_W.into_iter().enumerate() {
        room(b, flush)?;
        let text = ["<", if digits { "АБВ" } else { "123" }, "пробел", "Готово"][i];
        let (btn, label) = pill(b, page, text, i == 3, w, BOTTOM_H)?;
        b.style(label, Prop::TextFont, 0, F18 as i32)?;
        b.style(btn, Prop::Radius, 0, 14)?;
        b.align(btn, Align::TopLeft, x as i16, BOTTOM_Y as i16)?;
        match i {
            0 => s.bksp = btn,
            1 => (s.mode, s.mode_label) = (btn, label),
            2 => s.space = btn,
            _ => s.done = btn,
        }
        x += w + KEY_GAP;
    }
    Ok(s)
}

/// Switches the letter keys to digits or back, and the mode key's word.
pub fn set_mode(b: &mut Batch, s: &Screen, digits: bool) -> Result<(), LvError> {
    for (key, l) in s.key_labels.iter().enumerate() {
        b.text(*l, keys::label(digits, key))?;
    }
    b.text(s.mode_label, if digits { "АБВ" } else { "123" })
}

/// The typed text above the keys.
pub fn set_text(b: &mut Batch, s: &Screen, text: &str) -> Result<(), LvError> {
    b.text(s.shown, if text.is_empty() { "Название" } else { text })
}

/// The "now" screen: small title, headline, caption, the countdown, a bar, the lesson line, the clock, "Назад".
pub fn now(b: &mut Batch, flush: Flush) -> Result<Screen, LvError> {
    room(b, flush)?;
    let page = plain_page(b)?;
    let mut s = Screen { kind: Kind::Now, page, ..EMPTY };
    small_label(b, page, F18, true, 220, "Расписание", 36)?;
    s.head = small_label(b, page, F24, false, 300, "", 72)?;
    s.sub = small_label(b, page, F18, true, 300, "", 108)?;
    s.time = small_label(b, page, F48, false, 300, "--:--", 138)?;
    room(b, flush)?;
    let bar = b.create(Class::Bar, page)?;
    b.size(bar, 280, 10)?;
    b.align(bar, Align::TopMid, 0, 222)?;
    b.value(bar, 0, false)?;
    for (part, colour) in [(0, stock::LETTER_BG), (stock::INDICATOR, WHITE)] {
        b.style(bar, Prop::BgColor, part, colour)?;
        b.style(bar, Prop::BgOpa, part, 255)?;
        b.style(bar, Prop::Radius, part, CIRCLE)?;
    }
    s.bar = bar;
    s.line = small_label(b, page, F18, false, 320, "", 252)?;
    s.clock = small_label(b, page, F18, true, 260, "", 286)?;
    room(b, flush)?;
    let (back, _l) = pill(b, page, "Назад", true, 170, 56)?;
    b.align(back, Align::BottomMid, 0, -70)?;
    s.back = back;
    Ok(s)
}

/// What changes every second on the "now" screen.
pub fn now_draw(b: &mut Batch, s: &Screen, head: &str, sub: &str, time: &str, bar: i32, line: &str, clock: &str)
    -> Result<(), LvError> {
    b.text(s.head, head)?;
    b.text(s.sub, sub)?;
    b.text(s.time, time)?;
    b.value(s.bar, bar.clamp(0, 100), false)?;
    b.text(s.line, line)?;
    b.text(s.clock, clock)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn half(y: i32) -> i32 {
        let d = (y - 233).abs();
        (((233 * 233 - d * d).max(0)) as f64).sqrt() as i32
    }

    #[test]
    fn every_keyboard_row_fits_the_round_screen() {
        for (r, len) in ROW_LEN.into_iter().enumerate() {
            let width = len as i32 * KEY_W + (len as i32 - 1) * KEY_GAP;
            let top = ROW_Y0 + r as i32 * ROW_PITCH;
            let bottom = top + KEY_H;
            // the corner farthest from the centre line
            let y = if (top - 233).abs() > (bottom - 233).abs() { top } else { bottom };
            assert!(width / 2 + 4 <= half(y), "row {r}: {} <= {}", width / 2 + 4, half(y));
        }
        let total: i32 = BOTTOM_W.iter().sum::<i32>() + 3 * KEY_GAP;
        assert!(total / 2 + 4 <= half(BOTTOM_Y + BOTTOM_H), "bottom buttons");
    }

    #[test]
    fn the_keys_use_fewer_objects_than_the_budget() {
        // 33 keys and labels, 4 bottom buttons and labels, page, text: well under 192
        assert!(KEYS * 2 + 4 * 2 + 2 < 192);
    }
}
